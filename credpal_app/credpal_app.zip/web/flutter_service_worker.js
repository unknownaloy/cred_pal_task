'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"flutter_bootstrap.js": "12194e18c2d5b51346930acffef0d939",
"version.json": "c593626519eb7674f6082b5a390a1d5b",
"index.html": "bfbb14f518491dc424efe7839f1f4cf4",
"/": "bfbb14f518491dc424efe7839f1f4cf4",
"main.dart.js": "5d995784181161502ac68f57700204d9",
"flutter.js": "76f08d47ff9f5715220992f993002504",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"manifest.json": "71a65455e4aead5c1425edd55eab4329",
"assets/AssetManifest.json": "99cf994baf8aed2ac1aed5666079352f",
"assets/NOTICES": "61c9dcd998665198c9c9cb4e6abffd0a",
"assets/FontManifest.json": "087a70c7176e85666f249de1f2fb0efd",
"assets/AssetManifest.bin.json": "ec3021ec6777efd6c3a61c7f9f14513d",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "33b7d9392238c04c131b6ce224e13711",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/AssetManifest.bin": "997a9c58e7611d0e093177cb89a6a110",
"assets/fonts/MaterialIcons-Regular.otf": "c0ad29d56cfe3890223c02da3c6e0448",
"assets/assets/pngs/merchant8_logo.png": "ef91b30d2d140db0e558d3f07aecb75b",
"assets/assets/pngs/roll_one_item1.png": "2620537eadb0f41cbd235dbcd8c5ee99",
"assets/assets/pngs/merchant4_logo.png": "59cf13d923352cd4b154ae0ad2b4080d",
"assets/assets/pngs/merchant3.png": "b3303ba4cd287855d30c30c3247e9cf5",
"assets/assets/pngs/roll_one_item3.png": "98d0eb43dae3f3a9c503cf5624f383c0",
"assets/assets/pngs/roll_one_item2.png": "cbe3fc4973d2bbbef92ead567a6501a2",
"assets/assets/pngs/merchant2.png": "81ced6df85a44b88f714754040615b40",
"assets/assets/pngs/roll_one_badge2.png": "5eea0516442ef703650fff055184c843",
"assets/assets/pngs/merchant7.png": "fc1229854f0784d86924a7d04065f8a2",
"assets/assets/pngs/merchant5.png": "682857e53c5d09b8bdcaa34c9e059374",
"assets/assets/pngs/merchant9.png": "43d9abcffbf471f77d16763ad79633f2",
"assets/assets/pngs/roll_two_badge1.png": "4579be55befa9691758470459d24e982",
"assets/assets/pngs/roll_two_badge2.png": "3c917507994c9424e3cd5e33cef916e9",
"assets/assets/pngs/merchant10_logo.png": "9ca52fdfcdb90f4656ed9254fc4e7843",
"assets/assets/pngs/roll_two_item1.png": "034b150d81b9e3aef28837b322d9a6d6",
"assets/assets/pngs/roll_two_item2.png": "af0d49ef096cccf4f53e88405afdbece",
"assets/assets/pngs/roll_two_item3.png": "87b87a9d66d76b2d2f5edf27536e5f11",
"assets/assets/pngs/merchant6_logo.png": "33e4874a80efaba650e202c1a83e07d4",
"assets/assets/svgs/search.svg": "6199d61afcf09b0fb5b233b3fd4a64b5",
"assets/assets/svgs/alert.svg": "c4e4dee07e3151bf4af97916019fd464",
"assets/assets/svgs/scan.svg": "c7d72c7df5429a892c77eed69f70887f",
"assets/assets/jpegs/merchant1_logo.jpeg": "5317b36df5c9364a695edd0354665e05",
"assets/assets/fonts/roboto/Roboto-Medium.ttf": "7d752fb726f5ece291e2e522fcecf86d",
"assets/assets/fonts/roboto/Roboto-ExtraBold.ttf": "27fd63e58793434ce14a41e30176a4de",
"assets/assets/fonts/avenir/AvenirLTStd-Medium.otf": "4f995fa49446998983e05df9994dc96c",
"assets/assets/fonts/avenir/AvenirLTStd-Heavy.otf": "a7edaaca7240679d0cda0cce2c2e896e",
"assets/assets/fonts/avenir/AvenirLTStd-Light.otf": "0b78ec9d509f67bfe3f8458c9d285df0",
"assets/assets/fonts/avenir/AvenirLTStd-Black.otf": "b1abb878e2529cb5cb4450139844155d",
"assets/assets/fonts/avenir/AvenirLTStd-Roman.otf": "b1d7c6e085a31e9f5e4745c9aef6eb4b",
"canvaskit/skwasm_st.js": "d1326ceef381ad382ab492ba5d96f04d",
"canvaskit/skwasm.js": "f2ad9363618c5f62e813740099a80e63",
"canvaskit/skwasm.js.symbols": "80806576fa1056b43dd6d0b445b4b6f7",
"canvaskit/canvaskit.js.symbols": "68eb703b9a609baef8ee0e413b442f33",
"canvaskit/skwasm.wasm": "f0dfd99007f989368db17c9abeed5a49",
"canvaskit/chromium/canvaskit.js.symbols": "5a23598a2a8efd18ec3b60de5d28af8f",
"canvaskit/chromium/canvaskit.js": "ba4a8ae1a65ff3ad81c6818fd47e348b",
"canvaskit/chromium/canvaskit.wasm": "64a386c87532ae52ae041d18a32a3635",
"canvaskit/skwasm_st.js.symbols": "c7e7aac7cd8b612defd62b43e3050bdd",
"canvaskit/canvaskit.js": "6cfe36b4647fbfa15683e09e7dd366bc",
"canvaskit/canvaskit.wasm": "efeeba7dcc952dae57870d4df3111fad",
"canvaskit/skwasm_st.wasm": "56c3973560dfcbf28ce47cebe40f3206"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
